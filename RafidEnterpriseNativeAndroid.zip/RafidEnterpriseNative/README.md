# মেসার্স রাফিদ এন্টারপ্রাইজ - Native Android App

## Build করার নিয়ম
1. Android Studio / AIDE / Android IDE-তে এই project open করুন।
2. Build APK করুন।
3. APK install করুন।

## Backup/Restore
- Backup Save চাপলে Android-এর storage save picker খুলবে। যেখানে চান ফাইল save করুন।
- Import / Restore চাপলে backup JSON file select করলে data ফিরে আসবে।
- App uninstall করলে internal data মুছে যাবে, কিন্তু backup file import করলে সব history ফিরে আসবে।
