package com.rafid.enterprise;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    private static final String APP_NAME = "মেসার্স রাফিদ এন্টারপ্রাইজ";
    private static final String SALES_KEY = "RAFID_NATIVE_PERMANENT_SALES";
    private static final String OTHER_KEY = "RAFID_NATIVE_PERMANENT_OTHER";
    private static final int REQ_CREATE_BACKUP = 101;
    private static final int REQ_IMPORT_BACKUP = 102;

    private SharedPreferences prefs;
    private JSONArray sales = new JSONArray();
    private JSONArray others = new JSONArray();
    private LinearLayout main, content, nav;
    private TextView sumTotal, sumCash, sumDue;
    private String page = "sales";
    private String editSalesId = "", editOtherId = "";

    private EditText buyer, serial, kg, rate, cash, salesDate, salesNote;
    private Spinner product;
    private TextView liveTotal, liveCash, liveDue;
    private EditText otherName, otherSubject, otherAmount, otherDateTime, otherNote;
    private final String[] products = {"ঝাল", "হলুদ", "আম"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("rafid_native_store", MODE_PRIVATE);
        load();
        requestStoragePermissionOnce();
        buildUI();
        show("sales");
    }

    private void requestStoragePermissionOnce() {
        if (Build.VERSION.SDK_INT <= 32 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 9);
        }
    }

    private void load() {
        try { sales = new JSONArray(prefs.getString(SALES_KEY, "[]")); } catch(Exception e) { sales = new JSONArray(); }
        try { others = new JSONArray(prefs.getString(OTHER_KEY, "[]")); } catch(Exception e) { others = new JSONArray(); }
    }
    private void save() { prefs.edit().putString(SALES_KEY, sales.toString()).putString(OTHER_KEY, others.toString()).apply(); }

    private void buildUI() {
        main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL); main.setPadding(dp(10),dp(10),dp(10),dp(10));
        main.setBackground(grad(new int[]{Color.rgb(2,6,23),Color.rgb(15,23,42),Color.BLACK}, 0));
        setContentView(main);
        ScrollView sv = new ScrollView(this); main.addView(sv, new LinearLayout.LayoutParams(-1,-1));
        LinearLayout holder = new LinearLayout(this); holder.setOrientation(LinearLayout.VERTICAL); sv.addView(holder);

        LinearLayout hero = card(); hero.setBackground(roundGrad(new int[]{Color.rgb(15,23,42),Color.rgb(30,64,175)}, dp(24))); holder.addView(hero);
        LinearLayout br = new LinearLayout(this); br.setOrientation(LinearLayout.HORIZONTAL); br.setGravity(Gravity.CENTER_VERTICAL); hero.addView(br);
        TextView logo = new TextView(this); logo.setText("RE"); logo.setTextColor(Color.WHITE); logo.setTextSize(20); logo.setTypeface(Typeface.DEFAULT_BOLD); logo.setGravity(Gravity.CENTER);
        GradientDrawable lg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(250,204,21),Color.rgb(34,197,94),Color.rgb(56,189,248)}); lg.setShape(GradientDrawable.OVAL); lg.setStroke(dp(3), Color.WHITE); logo.setBackground(lg);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(62), dp(62)); llp.setMargins(0,0,dp(10),0); br.addView(logo, llp);
        LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); br.addView(texts, new LinearLayout.LayoutParams(0,-2,1));
        TextView title = tv(APP_NAME, 18, Color.rgb(250,204,21), true); title.setSingleLine(true); title.setEllipsize(TextUtils.TruncateAt.END); texts.addView(title);
        texts.addView(tv("বিক্রয় ও সাধারণ হিসাব খাতা", 12, Color.rgb(219,234,254), true));
        LinearLayout sm = new LinearLayout(this); sm.setOrientation(LinearLayout.HORIZONTAL); sm.setPadding(0,dp(12),0,0); hero.addView(sm);
        sumTotal = summary(sm,"বিক্রয় মোট","৳0",Color.rgb(147,197,253)); sumCash = summary(sm,"নগদ","৳0",Color.rgb(134,239,172)); sumDue = summary(sm,"বাকি","৳0",Color.rgb(252,165,165));
        nav = new LinearLayout(this); nav.setOrientation(LinearLayout.VERTICAL); nav.setPadding(0,dp(10),0,dp(8)); holder.addView(nav);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); holder.addView(content);
    }

    private void buildNav() {
        nav.removeAllViews(); LinearLayout r1 = row(); LinearLayout r2 = row(); nav.addView(r1); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(7),0,0); nav.addView(r2,lp);
        navBtn(r1,"🧾 বিক্রয়","sales"); navBtn(r1,"📝 বিষয়","other"); navBtn(r2,"📜 বিক্রয় হিস্ট্রি","salesHistory"); navBtn(r2,"📚 বিষয় হিস্ট্রি","otherHistory");
    }
    private void navBtn(LinearLayout r, String text, String target) { Button b=btn(text); b.setBackground(solid(target.equals(page)?Color.rgb(8,145,178):Color.argb(45,255,255,255), dp(15), Color.argb(40,255,255,255))); b.setOnClickListener(v->show(target)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(50),1); lp.setMargins(dp(3),0,dp(3),0); r.addView(b,lp); }
    private void show(String p) { page=p; if(nav!=null) buildNav(); content.removeAllViews(); updateSummary(); if(p.equals("sales")) salesPage(); else if(p.equals("other")) otherPage(); else if(p.equals("salesHistory")) salesHistory(); else otherHistory(); }

    private void salesPage() {
        LinearLayout c=card(); c.addView(section("নতুন বিক্রয় হিসাব","AUTO CALC"));
        buyer=input("যে কিনেছেন তার নাম", false); c.addView(field("যে কিনেছেন তার নাম", buyer));
        product=new Spinner(this); product.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, products)); c.addView(field("ঝাল নাকি হলুদ এবং আম", product));
        serial=input("যেমন: 001", false); c.addView(field("ক্রমিক নং Optional", serial));
        kg=input("যেমন: 5", true); rate=input("যেমন: 300", true); cash=input("যেমন: 1000", true); salesDate=input("yyyy-mm-dd", false); salesDate.setText(today()); salesNote=input("নোট", false); salesNote.setMinLines(2);
        c.addView(field("কত কেজি", kg)); c.addView(field("প্রতি কেজি কত টাকা", rate)); c.addView(field("নগদ কত", cash)); c.addView(field("তারিখ", salesDate)); c.addView(field("নোট / বিবরণ", salesNote));
        LinearLayout lr=row(); c.addView(lr); liveTotal=summary(lr,"মোট টাকা","৳0",Color.rgb(147,197,253)); liveCash=summary(lr,"নগদ","৳0",Color.rgb(134,239,172)); liveDue=summary(lr,"বাকি","৳0",Color.rgb(252,165,165));
        TextWatcher w=new SimpleWatcher(){ public void afterTextChanged(Editable e){ live(); }}; kg.addTextChangedListener(w); rate.addTextChangedListener(w); cash.addTextChangedListener(w);
        Button save=mainBtn("💾 বিক্রয় হিসাব সেভ করুন"); save.setOnClickListener(v->saveSale()); c.addView(save, new LinearLayout.LayoutParams(-1,dp(52))); content.addView(c); productCards(); backupPanel();
    }
    private void live(){ double k=num(kg),r=num(rate),ca=num(cash),t=k*r,d=Math.max(t-ca,0); liveTotal.setText(money(t)); liveCash.setText(money(ca)); liveDue.setText(money(d)); }
    private void saveSale(){ String n=buyer.getText().toString().trim(); double k=num(kg),r=num(rate),ca=num(cash),t=k*r,d=Math.max(t-ca,0); if(n.isEmpty()){toast("নাম লিখুন");return;} if(k<=0){toast("সঠিক কেজি লিখুন");return;} if(r<=0){toast("প্রতি কেজির দাম লিখুন");return;} try{ JSONObject o=new JSONObject(); o.put("id", editSalesId.isEmpty()?String.valueOf(System.currentTimeMillis()):editSalesId); o.put("buyerName",n); o.put("product",product.getSelectedItem().toString()); o.put("serialNo", serial.getText().toString().trim().isEmpty()?"N/A":serial.getText().toString().trim()); o.put("kg",k); o.put("rate",r); o.put("cash",ca); o.put("total",t); o.put("due",d); o.put("date",salesDate.getText().toString().trim()); o.put("note",salesNote.getText().toString().trim()); o.put("createdAt",System.currentTimeMillis()); upsert(sales,o,editSalesId); editSalesId=""; save(); toast("বিক্রয় হিসাব সেভ হয়েছে ✅"); show("sales"); }catch(Exception e){toast("Save error");} }

    private void productCards(){ LinearLayout c=card(); c.addView(section("প্রোডাক্ট অনুযায়ী হিসাব","LIVE TOTAL")); for(String p:products){ double k=0,t=0,d=0; for(int i=0;i<sales.length();i++)try{JSONObject o=sales.getJSONObject(i); if(p.equals(o.optString("product"))){k+=o.optDouble("kg"); t+=o.optDouble("total"); d+=o.optDouble("due");}}catch(Exception e){} TextView v=tv((p.equals("ঝাল")?"🌶️ ":p.equals("হলুদ")?"🟡 ":"🥭 ")+p+"\nমোট কেজি: "+k+" kg\nমোট টাকা: "+money(t)+"\nবাকি: "+money(d),14,Color.WHITE,true); v.setPadding(dp(12),dp(12),dp(12),dp(12)); v.setBackground(solid(Color.argb(90,2,6,23),dp(15),Color.argb(40,255,255,255))); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(8)); c.addView(v,lp);} content.addView(c); }

    private void otherPage(){ LinearLayout c=card(); c.addView(section("নতুন বিষয় হিসাব","SEPARATE")); otherName=input("নাম",false); otherSubject=input("বিষয়",false); otherSubject.setMinLines(2); otherAmount=input("যেমন: 500",true); otherDateTime=input("yyyy-mm-ddThh:mm",false); otherDateTime.setText(nowDT()); otherNote=input("নোট",false); otherNote.setMinLines(2); c.addView(field("নাম", otherName)); c.addView(field("বিষয়", otherSubject)); c.addView(field("টাকা", otherAmount)); c.addView(field("তারিখ ও সময়", otherDateTime)); c.addView(field("নোট / বিবরণ", otherNote)); Button save=mainBtn("💾 বিষয় হিসাব সেভ করুন"); save.setOnClickListener(v->saveOther()); c.addView(save,new LinearLayout.LayoutParams(-1,dp(52))); content.addView(c); otherSummary(); backupPanel(); }
    private void saveOther(){ String n=otherName.getText().toString().trim(),s=otherSubject.getText().toString().trim(); double a=num(otherAmount); if(n.isEmpty()){toast("নাম লিখুন");return;} if(s.isEmpty()){toast("বিষয় লিখুন");return;} if(a<=0){toast("সঠিক টাকা লিখুন");return;} try{JSONObject o=new JSONObject(); o.put("id",editOtherId.isEmpty()?String.valueOf(System.currentTimeMillis()):editOtherId); o.put("name",n); o.put("subject",s); o.put("amount",a); o.put("dateTime",otherDateTime.getText().toString().trim()); o.put("note",otherNote.getText().toString().trim()); o.put("createdAt",System.currentTimeMillis()); upsert(others,o,editOtherId); editOtherId=""; save(); toast("বিষয় হিসাব সেভ হয়েছে ✅"); show("other");}catch(Exception e){toast("Save error");}}
    private void otherSummary(){ double total=0,today=0; String td=today(); for(int i=0;i<others.length();i++)try{JSONObject o=others.getJSONObject(i); total+=o.optDouble("amount"); if(o.optString("dateTime").startsWith(td)) today+=o.optDouble("amount");}catch(Exception e){} LinearLayout c=card(); c.addView(section("বিষয় হিসাব সারাংশ","TOTAL")); c.addView(tv("মোট এন্ট্রি: "+others.length()+"\nমোট টাকা: "+money(total)+"\nআজকের টাকা: "+money(today),15,Color.WHITE,true)); content.addView(c); }

    private void salesHistory(){ LinearLayout c=card(); c.addView(section("বিক্রয় হিস্ট্রি","EDITABLE")); if(sales.length()==0)c.addView(tv("বিক্রয় হিস্ট্রি খালি।",15,Color.rgb(148,163,184),false)); for(int i=sales.length()-1;i>=0;i--)try{JSONObject o=sales.getJSONObject(i); c.addView(entry(o.optString("buyerName"),money(o.optDouble("total")),"ক্রমিক নং: "+o.optString("serialNo","N/A")+"\nপ্রোডাক্ট: "+o.optString("product")+"\nকেজি: "+o.optDouble("kg")+" kg × "+money(o.optDouble("rate"))+" = "+money(o.optDouble("total"))+"\nনগদ: "+money(o.optDouble("cash"))+" | বাকি: "+money(o.optDouble("due"))+"\nতারিখ: "+o.optString("date")+"\nনোট: "+(o.optString("note").isEmpty()?"নেই":o.optString("note")),o.optString("id"),true));}catch(Exception e){} content.addView(c); backupPanel(); }
    private void otherHistory(){ LinearLayout c=card(); c.addView(section("বিষয় হিস্ট্রি","SEPARATE")); if(others.length()==0)c.addView(tv("বিষয় হিস্ট্রি খালি।",15,Color.rgb(148,163,184),false)); for(int i=others.length()-1;i>=0;i--)try{JSONObject o=others.getJSONObject(i); c.addView(entry(o.optString("name"),money(o.optDouble("amount")),"বিষয়: "+o.optString("subject")+"\nতারিখ ও সময়: "+o.optString("dateTime")+"\nনোট: "+(o.optString("note").isEmpty()?"নেই":o.optString("note")),o.optString("id"),false));}catch(Exception e){} content.addView(c); backupPanel(); }
    private View entry(String title,String amount,String meta,String id,boolean isSale){ LinearLayout e=card(); TextView t=tv(title+"\n"+amount,16,Color.WHITE,true); e.addView(t); TextView m=tv(meta,13,Color.rgb(203,213,225),false); m.setPadding(0,dp(8),0,dp(8)); e.addView(m); LinearLayout r=row(); Button ed=btn("✏️ Edit"), del=btn("Delete"); del.setBackground(solid(Color.rgb(239,68,68),dp(14),0)); ed.setOnClickListener(v->{if(isSale)editSale(id);else editOther(id);}); del.setOnClickListener(v->{if(isSale)deleteSale(id);else deleteOther(id);}); r.addView(ed,new LinearLayout.LayoutParams(0,dp(45),1)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1); lp.setMargins(dp(8),0,0,0); r.addView(del,lp); e.addView(r); return e; }

    private void editSale(String id){ try{ for(int i=0;i<sales.length();i++){JSONObject o=sales.getJSONObject(i); if(id.equals(o.optString("id"))){show("sales"); buyer.setText(o.optString("buyerName")); product.setSelection(Arrays.asList(products).indexOf(o.optString("product"))); serial.setText(o.optString("serialNo").equals("N/A")?"":o.optString("serialNo")); kg.setText(String.valueOf(o.optDouble("kg"))); rate.setText(String.valueOf(o.optDouble("rate"))); cash.setText(String.valueOf(o.optDouble("cash"))); salesDate.setText(o.optString("date")); salesNote.setText(o.optString("note")); editSalesId=id; live(); return;}}}catch(Exception e){} }
    private void editOther(String id){ try{ for(int i=0;i<others.length();i++){JSONObject o=others.getJSONObject(i); if(id.equals(o.optString("id"))){show("other"); otherName.setText(o.optString("name")); otherSubject.setText(o.optString("subject")); otherAmount.setText(String.valueOf(o.optDouble("amount"))); otherDateTime.setText(o.optString("dateTime")); otherNote.setText(o.optString("note")); editOtherId=id; return;}}}catch(Exception e){} }
    private void deleteSale(String id){ sales=remove(sales,id); save(); toast("মুছে ফেলা হয়েছে"); show("salesHistory"); }
    private void deleteOther(String id){ others=remove(others,id); save(); toast("মুছে ফেলা হয়েছে"); show("otherHistory"); }

    private void backupPanel(){ LinearLayout c=card(); c.addView(section("Backup & Restore","SAFE DATA")); LinearLayout r=row(); Button b=btn("⬇️ Backup Save"), im=btn("⬆️ Import / Restore"); b.setOnClickListener(v->backup()); im.setOnClickListener(v->restore()); r.addView(b,new LinearLayout.LayoutParams(0,dp(50),1)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(50),1); lp.setMargins(dp(8),0,0,0); r.addView(im,lp); c.addView(r); content.addView(c); }
    private void backup(){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json"); i.putExtra(Intent.EXTRA_TITLE,"rafid-enterprise-backup-"+today()+".json"); startActivityForResult(i,REQ_CREATE_BACKUP); }
    private void restore(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json"); startActivityForResult(i,REQ_IMPORT_BACKUP); }
    @Override protected void onActivityResult(int req,int res,Intent data){ super.onActivityResult(req,res,data); if(res!=RESULT_OK||data==null||data.getData()==null)return; Uri u=data.getData(); try{ if(req==REQ_CREATE_BACKUP){ JSONObject b=new JSONObject(); b.put("app",APP_NAME); b.put("createdAt",new Date().toString()); b.put("salesEntries",sales); b.put("otherEntries",others); OutputStream out=getContentResolver().openOutputStream(u); out.write(b.toString(2).getBytes("UTF-8")); out.close(); toast("Backup save হয়েছে ✅"); } else { String txt=read(getContentResolver().openInputStream(u)); JSONObject b=new JSONObject(txt); sales=b.getJSONArray("salesEntries"); others=b.getJSONArray("otherEntries"); save(); toast("Data restore হয়েছে ✅"); show("sales"); }}catch(Exception e){toast("File error");}}
    private String read(InputStream in)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();return out.toString("UTF-8");}

    private void updateSummary(){ double t=0,c=0,d=0; for(int i=0;i<sales.length();i++)try{JSONObject o=sales.getJSONObject(i);t+=o.optDouble("total");c+=o.optDouble("cash");d+=o.optDouble("due");}catch(Exception e){} if(sumTotal!=null){sumTotal.setText(money(t));sumCash.setText(money(c));sumDue.setText(money(d));} }
    private void upsert(JSONArray arr,JSONObject o,String id)throws Exception{ if(id==null||id.isEmpty()){arr.put(o);return;} for(int i=0;i<arr.length();i++)if(id.equals(arr.getJSONObject(i).optString("id"))){arr.put(i,o);return;} arr.put(o);}
    private JSONArray remove(JSONArray arr,String id){JSONArray n=new JSONArray(); for(int i=0;i<arr.length();i++)try{if(!id.equals(arr.getJSONObject(i).optString("id")))n.put(arr.getJSONObject(i));}catch(Exception e){} return n;}

    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(14),dp(14),dp(14),dp(14)); l.setBackground(solid(Color.argb(235,15,23,42),dp(22),Color.argb(35,255,255,255))); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(12)); l.setLayoutParams(lp); return l; }
    private View section(String title,String tag){ LinearLayout r=row(); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0,0,0,dp(10)); TextView t=tv(title,19,Color.WHITE,true); r.addView(t,new LinearLayout.LayoutParams(0,-2,1)); TextView g=tv(tag,11,Color.rgb(15,23,42),true); g.setPadding(dp(8),dp(5),dp(8),dp(5)); g.setBackground(solid(Color.rgb(250,204,21),dp(20),0)); r.addView(g); return r; }
    private View field(String label, View child){ LinearLayout w=new LinearLayout(this); w.setOrientation(LinearLayout.VERTICAL); w.addView(tv(label,13,Color.rgb(203,213,225),true)); w.addView(child,new LinearLayout.LayoutParams(-1, child instanceof EditText && ((EditText)child).getMinLines()>1?dp(78):dp(50))); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(10)); w.setLayoutParams(lp); return w; }
    private EditText input(String hint, boolean number){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(100,116,139)); e.setTextColor(Color.WHITE); e.setTextSize(15); e.setPadding(dp(12),0,dp(12),0); e.setSingleLine(true); e.setBackground(solid(Color.argb(170,2,6,23),dp(15),Color.argb(35,255,255,255))); if(number)e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL); return e; }
    private TextView tv(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setSingleLine(false); if(bold)t.setTypeface(Typeface.DEFAULT_BOLD); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setAllCaps(false); b.setText(s); b.setTextSize(13); b.setTypeface(Typeface.DEFAULT_BOLD); b.setTextColor(Color.WHITE); b.setBackground(solid(Color.argb(45,255,255,255),dp(14),Color.argb(40,255,255,255))); return b; }
    private Button mainBtn(String s){ Button b=btn(s); b.setBackground(roundGrad(new int[]{Color.rgb(56,189,248),Color.rgb(37,99,235),Color.rgb(34,197,94)},dp(16))); return b; }
    private TextView summary(LinearLayout p,String l,String v,int color){ LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setGravity(Gravity.CENTER); b.setPadding(dp(4),dp(8),dp(4),dp(8)); b.setBackground(solid(Color.argb(130,2,6,23),dp(15),Color.argb(35,255,255,255))); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(3),0,dp(3),0); p.addView(b,lp); TextView lab=tv(l,11,Color.rgb(203,213,225),true); lab.setGravity(Gravity.CENTER); b.addView(lab); TextView val=tv(v,13,color,true); val.setGravity(Gravity.CENTER); b.addView(val); return val; }
    private Drawable solid(int color,int rad,int stroke){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(rad); if(stroke!=0)g.setStroke(dp(1),stroke); return g; }
    private Drawable roundGrad(int[] colors,int rad){ GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors); g.setCornerRadius(rad); return g; }
    private Drawable grad(int[] colors,int rad){ return new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors); }
    private double num(EditText e){ try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;} }
    private String money(double n){ return "৳"+String.format(Locale.US,"%,.0f",n); }
    private String today(){ return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); }
    private String nowDT(){ return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm",Locale.US).format(new Date()); }
    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    abstract class SimpleWatcher implements TextWatcher{ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){} }
}
